~/.icons/mytheme

ln -s ~/Sync/Wallpapers/Themes/mytheme/ ~/.icons/


xterm: text -> arrow
pointer: hand -> arrow
